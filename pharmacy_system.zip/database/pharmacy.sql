CREATE DATABASE pharmacy;
USE pharmacy;

CREATE TABLE users(
id INT AUTO_INCREMENT PRIMARY KEY,
name VARCHAR(100),
email VARCHAR(100),
password VARCHAR(255),
role VARCHAR(20)
);

CREATE TABLE medicines(
id INT AUTO_INCREMENT PRIMARY KEY,
name VARCHAR(100),
price DECIMAL(10,2),
stock INT
);

INSERT INTO users(name,email,password,role)
VALUES('Admin','admin@pharmacy.com',
'$2y$10$u1Hk5Fj1VJxZKx4yO8lHjO4XEX3AfDdc/K1Ji/7/0GINuD/7/UZDa','admin');
