<?php
include "config.php";

$n=$_POST['name'];
$p=$_POST['price'];
$s=$_POST['stock'];

$conn->query("INSERT INTO medicines(name,price,stock)
VALUES('$n','$p','$s')");

echo "Saved";
?>
