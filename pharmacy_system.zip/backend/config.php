<?php
$conn = new mysqli("localhost","root","","pharmacy");
if($conn->connect_error){
 die("DB Error");
}
?>
