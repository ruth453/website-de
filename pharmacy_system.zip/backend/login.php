<?php
include "config.php";
$email=$_POST['email'];
$pass=$_POST['password'];

$q=$conn->query("SELECT * FROM users WHERE email='$email'");
$u=$q->fetch_assoc();

if($u && password_verify($pass,$u['password'])){
 session_start();
 $_SESSION['id']=$u['id'];
 header("Location: ../frontend/dashboard.html");
}else{
 echo "Login Failed";
}
?>
