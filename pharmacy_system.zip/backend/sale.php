<?php
include "config.php";

$id=$_POST['medicine'];
$q=$_POST['qty'];

$conn->query("UPDATE medicines SET stock=stock-$q WHERE id=$id");

echo "Sale Done";
?>
